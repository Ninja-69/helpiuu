import { Inter } from "next/font/google"

export const geist = Inter({
  subsets: ["latin"],
  display: "swap",
})
